# Changelog

All notable changes to Termino.js will be documented in this file.

## [1.0.0] - (Dec 6, 2022)

Initial Release.

### Added

- What was added.


<!--
These Markdown anchors provide a link to the diff for each release. They should be
updated any time a new release is cut.
-->
[1.0.0]: /v1.0.0
